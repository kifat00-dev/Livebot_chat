import logging
import sqlite3
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    ContextTypes,
    filters
)

# ================= CONFIG =================

BOT_TOKEN = "9290632324:AAHJe2t-k2W9Ux3E7_xRALnxKEub0hCAyeU"
ADMIN_ID = 7441057457

DB = "livechat_v2.db"
PAGE_SIZE = 8

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

# ================= DATABASE =================

def db():
    return sqlite3.connect(DB)


def setup_db():
    con = db()

    con.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            name TEXT,
            username TEXT,
            joined_at TEXT
        )
    """)

    con.execute("""
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            direction TEXT,
            content_type TEXT,
            message_text TEXT,
            created_at TEXT,
            admin_message_id INTEGER
        )
    """)

    con.execute("""
        CREATE TABLE IF NOT EXISTS blocked (
            user_id INTEGER PRIMARY KEY
        )
    """)

    con.execute("""
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        )
    """)

    con.commit()
    con.close()


def save_user(user):
    con = db()
    con.execute("""
        INSERT INTO users (user_id, name, username, joined_at)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(user_id) DO UPDATE SET
        name=excluded.name,
        username=excluded.username
    """, (
        user.id,
        user.full_name,
        user.username,
        datetime.now().isoformat()
    ))
    con.commit()
    con.close()


def save_message(user_id, direction, msg, admin_message_id=None):
    content_type = "text"
    message_text = msg.text or msg.caption or ""

    if msg.photo:
        content_type = "photo"
    elif msg.video:
        content_type = "video"
    elif msg.voice:
        content_type = "voice"
    elif msg.audio:
        content_type = "audio"
    elif msg.document:
        content_type = "document"
    elif msg.sticker:
        content_type = "sticker"
    elif msg.animation:
        content_type = "animation"
    elif msg.video_note:
        content_type = "video_note"

    con = db()
    con.execute("""
        INSERT INTO messages
        (user_id, direction, content_type, message_text, created_at, admin_message_id)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (
        user_id,
        direction,
        content_type,
        message_text,
        datetime.now().isoformat(timespec="seconds"),
        admin_message_id
    ))
    con.commit()
    con.close()


def get_setting(key):
    con = db()
    result = con.execute(
        "SELECT value FROM settings WHERE key=?",
        (key,)
    ).fetchone()
    con.close()
    return result[0] if result else None


def set_setting(key, value):
    con = db()
    con.execute(
        "INSERT OR REPLACE INTO settings VALUES (?, ?)",
        (key, str(value))
    )
    con.commit()
    con.close()


def clear_mode():
    set_setting("mode", "idle")
    set_setting("target", "")


def is_blocked(user_id):
    con = db()
    result = con.execute(
        "SELECT 1 FROM blocked WHERE user_id=?",
        (user_id,)
    ).fetchone()
    con.close()
    return result is not None


# ================= ADMIN DASHBOARD =================

def dashboard_keyboard():
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("👥 All Users", callback_data="users:0"),
            InlineKeyboardButton("📊 Statistics", callback_data="stats")
        ],
        [
            InlineKeyboardButton("🔍 Search User", callback_data="search"),
            InlineKeyboardButton("📢 Broadcast", callback_data="broadcast")
        ],
        [
            InlineKeyboardButton("💬 Active Chat", callback_data="active"),
            InlineKeyboardButton("❌ Close", callback_data="close")
        ]
    ])


async def admin_panel(update, context):
    if update.effective_user.id != ADMIN_ID:
        return

    clear_mode()

    await update.effective_message.reply_text(
        "👑 PREMIUM ADMIN DASHBOARD\n\n"
        "Welcome Admin!\n"
        "Yahan se apne Live Chat Bot ko manage karein.",
        reply_markup=dashboard_keyboard()
    )


async def show_users(query, page=0):
    con = db()
    users = con.execute("""
        SELECT user_id, name, username
        FROM users ORDER BY rowid DESC
        LIMIT ? OFFSET ?
    """, (PAGE_SIZE, page * PAGE_SIZE)).fetchall()

    total = con.execute(
        "SELECT COUNT(*) FROM users"
    ).fetchone()[0]
    con.close()

    buttons = []

    for uid, name, username in users:
        label = (name or "Unknown")[:22]
        buttons.append([
            InlineKeyboardButton(
                f"👤 {label}",
                callback_data=f"open:{uid}"
            )
        ])

    navigation = []
    if page > 0:
        navigation.append(
            InlineKeyboardButton("⬅️ Previous", callback_data=f"users:{page-1}")
        )

    if (page + 1) * PAGE_SIZE < total:
        navigation.append(
            InlineKeyboardButton("Next ➡️", callback_data=f"users:{page+1}")
        )

    if navigation:
        buttons.append(navigation)

    buttons.append([
        InlineKeyboardButton("🏠 Dashboard", callback_data="dashboard")
    ])

    await query.edit_message_text(
        f"👥 ALL USERS\n\nTotal Users: {total}\nPage: {page+1}",
        reply_markup=InlineKeyboardMarkup(buttons)
    )


async def show_stats(query):
    con = db()

    users = con.execute(
        "SELECT COUNT(*) FROM users"
    ).fetchone()[0]

    messages = con.execute(
        "SELECT COUNT(*) FROM messages"
    ).fetchone()[0]

    blocked = con.execute(
        "SELECT COUNT(*) FROM blocked"
    ).fetchone()[0]

    today = datetime.now().date().isoformat()

    new_users = con.execute(
        "SELECT COUNT(*) FROM users WHERE joined_at LIKE ?",
        (today + "%",)
    ).fetchone()[0]

    con.close()

    await query.edit_message_text(
        "📊 BOT STATISTICS\n\n"
        f"👥 Total Users: {users}\n"
        f"🆕 Today's New Users: {new_users}\n"
        f"💬 Total Messages: {messages}\n"
        f"🚫 Blocked Users: {blocked}",
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton("🏠 Dashboard", callback_data="dashboard")
        ]])
    )


async def open_user(query, user_id):
    con = db()

    user = con.execute(
        "SELECT name, username FROM users WHERE user_id=?",
        (user_id,)
    ).fetchone()

    count = con.execute(
        "SELECT COUNT(*) FROM messages WHERE user_id=?",
        (user_id,)
    ).fetchone()[0]

    history = con.execute("""
        SELECT direction, content_type, message_text, created_at
        FROM messages WHERE user_id=?
        ORDER BY id DESC LIMIT 8
    """, (user_id,)).fetchall()

    con.close()

    if not user:
        await query.answer("User not found", show_alert=True)
        return

    blocked = is_blocked(user_id)

    set_setting("mode", "chat")
    set_setting("target", user_id)

    history_text = ""
    for direction, kind, msg, time in reversed(history):
        history_text += (
            f"\n{'👤 User' if direction == 'in' else '👑 Admin'} "
            f"[{kind}]: {(msg or '')[:100]}\n"
        )

    buttons = [
        [
            InlineKeyboardButton("💬 Chat Selected", callback_data="active"),
            InlineKeyboardButton(
                "🔓 Unblock" if blocked else "🚫 Block",
                callback_data=f"block:{user_id}"
            )
        ],
        [
            InlineKeyboardButton("👥 All Users", callback_data="users:0"),
            InlineKeyboardButton("🏠 Dashboard", callback_data="dashboard")
        ]
    ]

    await query.edit_message_text(
        f"💬 PERSONAL CHAT\n\n"
        f"👤 Name: {user[0]}\n"
        f"🔗 Username: @{user[1] or 'Not Available'}\n"
        f"🆔 ID: {user_id}\n"
        f"📩 Total Messages: {count}\n"
        f"🚫 Blocked: {'Yes' if blocked else 'No'}\n\n"
        f"📜 RECENT HISTORY\n{history_text}\n"
        "Ab Termux/Bot ke isi chat mein apna message bhejein. "
        "Woh selected user ko chala jayega.",
        reply_markup=InlineKeyboardMarkup(buttons)
    )


# ================= BUTTON HANDLER =================

async def buttons(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query

    if query.from_user.id != ADMIN_ID:
        await query.answer("Access denied", show_alert=True)
        return

    await query.answer()
    data = query.data

    if data == "dashboard":
        clear_mode()
        await query.edit_message_text(
            "👑 PREMIUM ADMIN DASHBOARD",
            reply_markup=dashboard_keyboard()
        )

    elif data.startswith("users:"):
        await show_users(query, int(data.split(":")[1]))

    elif data == "stats":
        await show_stats(query)

    elif data.startswith("open:"):
        await open_user(query, int(data.split(":")[1]))

    elif data.startswith("block:"):
        uid = int(data.split(":")[1])

        if is_blocked(uid):
            con = db()
            con.execute("DELETE FROM blocked WHERE user_id=?", (uid,))
            con.commit()
            con.close()
        else:
            con = db()
            con.execute("INSERT OR IGNORE INTO blocked VALUES (?)", (uid,))
            con.commit()
            con.close()

        await open_user(query, uid)

    elif data == "broadcast":
        set_setting("mode", "broadcast")
        set_setting("target", "")
        await query.edit_message_text(
            "📢 BROADCAST MODE\n\n"
            "Ab apna text, photo, video ya document bhejein.\n"
            "Use all registered users ko bheja jayega.\n\n"
            "/cancel se cancel karein."
        )

    elif data == "search":
        set_setting("mode", "search")
        await query.edit_message_text(
            "🔍 Search ke liye user ka naam, username ya ID bhejein."
        )

    elif data == "active":
        target = get_setting("target")
        if target and get_setting("mode") == "chat":
            await query.edit_message_text(
                f"💬 Active Chat: {target}\n\n"
                "Ab apna message bhejein.\n"
                "/cancel se chat band karein."
            )
        else:
            await query.edit_message_text(
                "Abhi koi selected chat nahi hai.",
                reply_markup=dashboard_keyboard()
            )

    elif data == "close":
        await query.edit_message_text("Dashboard closed.")


# ================= SEARCH =================

async def search_user(update, context):
    if update.effective_user.id != ADMIN_ID:
        return

    if not context.args:
        await update.message.reply_text("Use: /search name_or_id")
        return

    term = " ".join(context.args)

    con = db()
    rows = con.execute("""
        SELECT user_id, name, username FROM users
        WHERE name LIKE ? OR username LIKE ? OR CAST(user_id AS TEXT)=?
        LIMIT 15
    """, (f"%{term}%", f"%{term}%", term)).fetchall()
    con.close()

    if not rows:
        await update.message.reply_text("No users found.")
        return

    buttons = []
    for uid, name, username in rows:
        buttons.append([InlineKeyboardButton(
            f"👤 {(name or 'Unknown')[:22]} | {uid}",
            callback_data=f"open:{uid}"
        )])

    await update.message.reply_text(
        "🔍 SEARCH RESULTS",
        reply_markup=InlineKeyboardMarkup(buttons)
    )


# ================= MAIN MESSAGE HANDLER =================

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.effective_message
    user = update.effective_user

    if not msg or not user:
        return

    # ADMIN MESSAGES
    if user.id == ADMIN_ID:
        mode = get_setting("mode")
        target = get_setting("target")

        if mode == "search":
            term = msg.text or msg.caption or ""
            con = db()
            rows = con.execute("""
                SELECT user_id, name FROM users
                WHERE name LIKE ? OR username LIKE ?
                OR CAST(user_id AS TEXT)=?
                LIMIT 15
            """, (f"%{term}%", f"%{term}%", term)).fetchall()
            con.close()

            buttons_list = [[
                InlineKeyboardButton(
                    f"👤 {(name or 'Unknown')[:20]} | {uid}",
                    callback_data=f"open:{uid}"
                )
            ] for uid, name in rows]

            if buttons_list:
                await msg.reply_text(
                    "🔍 SEARCH RESULTS",
                    reply_markup=InlineKeyboardMarkup(buttons_list)
                )
            else:
                await msg.reply_text("No users found.")
            set_setting("mode", "idle")
            return

        if mode == "broadcast":
            con = db()
            users = con.execute(
                "SELECT user_id FROM users"
            ).fetchall()
            con.close()

            success = 0
            failed = 0

            for (uid,) in users:
                if is_blocked(uid):
                    continue
                try:
                    await context.bot.copy_message(
                        chat_id=uid,
                        from_chat_id=ADMIN_ID,
                        message_id=msg.message_id
                    )
                    success += 1
                except Exception:
                    failed += 1

            save_message(0, "broadcast", msg)
            clear_mode()

            await msg.reply_text(
                f"📢 BROADCAST COMPLETE\n\n"
                f"✅ Sent: {success}\n"
                f"❌ Failed: {failed}"
            )
            return

        if mode == "chat" and target:
            uid = int(target)

            if is_blocked(uid):
                await msg.reply_text("❌ This user is blocked. Unblock first.")
                return

            try:
                await context.bot.copy_message(
                    chat_id=uid,
                    from_chat_id=ADMIN_ID,
                    message_id=msg.message_id
                )
                save_message(uid, "out", msg)
                await msg.reply_text("✅ Message delivered.")
            except Exception:
                await msg.reply_text(
                    "❌ Delivery failed. User may have blocked the bot."
                )
            return

        await msg.reply_text(
            "👑 Admin Panel ke liye /admin likhein.\n"
            "Kisi user ko search karne ke liye /search naam likhein."
        )
        return

    # USER MESSAGES
    save_user(user)

    if is_blocked(user.id):
        await msg.reply_text(
            "Aap filhaal is support service ka use nahi kar sakte."
        )
        return

    try:
        notification = await context.bot.send_message(
            ADMIN_ID,
            f"📩 NEW USER MESSAGE\n\n"
            f"👤 Name: {user.full_name}\n"
            f"🔗 Username: @{user.username or 'Not Available'}\n"
            f"🆔 ID: {user.id}",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton(
                    "💬 Open Chat",
                    callback_data=f"open:{user.id}"
                )
            ]])
        )

        copied = await context.bot.copy_message(
            chat_id=ADMIN_ID,
            from_chat_id=msg.chat_id,
            message_id=msg.message_id
        )

        save_message(user.id, "in", msg, copied.message_id)

    except Exception:
        logging.exception("User message delivery failed")
        await msg.reply_text("Message deliver nahi hua. Kripya dobara try karein.")


# ================= COMMANDS =================

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user

    if user.id == ADMIN_ID:
        await admin_panel(update, context)
        return

    save_user(user)

    await update.message.reply_text(
        f"How are you 🫵 User! ❤️\n\n"
        "Welcome to Live Chat Support.\n"
        "Aap apna message, photo, video ya file bhej sakte hain.\n"
        "Admin jald hi aapko reply karega. 💬"
    )

    await context.bot.send_message(
        ADMIN_ID,
        f"🆕 NEW USER JOINED\n\n"
        f"👤 Name: {user.full_name}\n"
        f"🔗 Username: @{user.username or 'Not Available'}\n"
        f"🆔 ID: {user.id}",
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton(
                "💬 Open Chat",
                callback_data=f"open:{user.id}"
            )
        ]])
    )


async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return

    clear_mode()
    await update.message.reply_text(
        "✅ Current mode cancelled.",
        reply_markup=dashboard_keyboard()
    )


# ================= RUN BOT =================

def main():
    if BOT_TOKEN == "YOUR_BOT_TOKEN":
        raise ValueError("Please set your BOT_TOKEN first.")

    setup_db()

    app = Application.builder().token(BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("admin", admin_panel))
    app.add_handler(CommandHandler("stats", stats_command))
    app.add_handler(CommandHandler("search", search_user))
    app.add_handler(CommandHandler("cancel", cancel))

    app.add_handler(CallbackQueryHandler(buttons))

    app.add_handler(
        MessageHandler(
            filters.ALL & ~filters.COMMAND,
            handle_message
        )
    )

    print("🔥 PREMIUM LIVE CHAT V2.0 STARTED!")
    app.run_polling()


async def stats_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return

    con = db()
    users = con.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    messages = con.execute("SELECT COUNT(*) FROM messages").fetchone()[0]
    con.close()

    await update.message.reply_text(
        f"📊 STATISTICS\n\nUsers: {users}\nMessages: {messages}"
    )


if __name__ == "__main__":
    main()
